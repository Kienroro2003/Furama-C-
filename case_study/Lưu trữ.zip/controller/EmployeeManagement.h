//
// Created by Kienroro on 22/04/2022.
//
#include"../service/EmployeeService.h"


#ifndef CASE_STUDY_EMPLOYEEMANAGEMENT_H
#define CASE_STUDY_EMPLOYEEMANAGEMENT_H


class EmployeeManagement {
public:
    void employeeMenu();

};


#endif //CASE_STUDY_EMPLOYEEMANAGEMENT_H
