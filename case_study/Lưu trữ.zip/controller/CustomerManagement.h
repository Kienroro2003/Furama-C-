//
// Created by Kienroro on 22/04/2022.
//
#include "../header.h"

#ifndef CASE_STUDY_CUSTOMERMANAGEMENT_H
#define CASE_STUDY_CUSTOMERMANAGEMENT_H


class CustomerManagement {
public:
    void customerMenu();
};


#endif //CASE_STUDY_CUSTOMERMANAGEMENT_H
