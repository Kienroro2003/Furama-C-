//
// Created by Kienroro on 14/05/2022.
//
#include "../header.h"

#ifndef CASE_STUDY_FACILITYMANAGEMENT_H
#define CASE_STUDY_FACILITYMANAGEMENT_H


class FacilityManagement {
public:
    void facilityMenu();
};


#endif //CASE_STUDY_FACILITYMANAGEMENT_H
