//
// Created by Kienroro on 14/05/2022.
//
#include "../header.h"

#ifndef CASE_STUDY_BOOKINGMANAGEMENT_H
#define CASE_STUDY_BOOKINGMANAGEMENT_H


class BookingManagement {
public:
    void bookingMenu();
};


#endif //CASE_STUDY_BOOKINGMANAGEMENT_H
