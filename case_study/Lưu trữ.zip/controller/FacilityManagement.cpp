//
// Created by Kienroro on 14/05/2022.
//

#include "FacilityManagement.h"

void addNewFacility() {
    while (1) {
        cout << "1. Add New Villa" << endl;
        cout << "2. Add New Room" << endl;
        cout << "3. Add New House" << endl;
        cout << "4. Back to menu" << endl;
        cout << "Enter choose: ";
        int choose;
        cin >> choose;
        cin.ignore();
        switch (choose) {
            case 1: {

                break;
            }
            case 2: {

                break;
            }
            case 3: {

                break;
            }
            case 4: {
                return;
            }
        }
    }
}

void FacilityManagement::facilityMenu() {
    while (1) {
        cout << "1. Display list facility" << endl;
        cout << "2. Add new facility" << endl;
        cout << "3. Display list facility maintenance" << endl;
        cout << "4. Return main menu" << endl;
        cout << "Enter choose: ";
        int choose;
        cin >> choose;
        cin.ignore();
        switch (choose) {
            case 1: {

                break;
            }
            case 2: {
                addNewFacility();
                break;
            }
            case 3: {

                break;
            }
            case 4: {
                return;
            }
        }
    }


}
