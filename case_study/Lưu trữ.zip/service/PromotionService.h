//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_PROMOTIONSERVICE_H
#define CASE_STUDY_PROMOTIONSERVICE_H


class PromotionService {

};


#endif //CASE_STUDY_PROMOTIONSERVICE_H
