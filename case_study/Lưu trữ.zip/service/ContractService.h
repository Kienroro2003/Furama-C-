//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_CONTRACTSERVICE_H
#define CASE_STUDY_CONTRACTSERVICE_H


class ContractService {

};


#endif //CASE_STUDY_CONTRACTSERVICE_H
