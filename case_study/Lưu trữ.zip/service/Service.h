//
// Created by Kienroro on 08/05/2022.
//

#ifndef CASE_STUDY_SERVICE_H
#define CASE_STUDY_SERVICE_H


class Service {
public:
    virtual void add() = 0;

    virtual void display() = 0;

    virtual void edit() = 0;

};


#endif //CASE_STUDY_SERVICE_H
