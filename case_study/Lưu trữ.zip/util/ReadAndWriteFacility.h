//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_READANDWRITEFACILITY_H
#define CASE_STUDY_READANDWRITEFACILITY_H


class ReadAndWriteFacility {

};


#endif //CASE_STUDY_READANDWRITEFACILITY_H
