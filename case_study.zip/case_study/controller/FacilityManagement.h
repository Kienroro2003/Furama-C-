//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_FACILITYMANAGEMENT_H
#define CASE_STUDY_FACILITYMANAGEMENT_H


class FacilityManagement {

};


#endif //CASE_STUDY_FACILITYMANAGEMENT_H
