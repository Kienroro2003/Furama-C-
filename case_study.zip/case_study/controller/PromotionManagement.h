//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_PROMOTIONMANAGEMENT_H
#define CASE_STUDY_PROMOTIONMANAGEMENT_H


class PromotionManagement {

};


#endif //CASE_STUDY_PROMOTIONMANAGEMENT_H
