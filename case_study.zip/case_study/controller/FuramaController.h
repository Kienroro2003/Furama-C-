//
// Created by Kienroro on 22/04/2022.
//
#include "../header.h"
#include "EmployeeManagement.h"
#include "CustomerManagement.h"

#ifndef CASE_STUDY_FACILITYMANAGEM_H
#define CASE_STUDY_FACILITYMANAGEM_H


class FuramaController {
public:
    void displayMainMenu();


};


#endif //CASE_STUDY_FACILITYMANAGEM_H
