//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_READANDWRITECONTRACT_H
#define CASE_STUDY_READANDWRITECONTRACT_H


class ReadAndWriteContract {

};


#endif //CASE_STUDY_READANDWRITECONTRACT_H
