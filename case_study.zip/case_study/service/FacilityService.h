//
// Created by Kienroro on 14/05/2022.
//

#ifndef CASE_STUDY_FACILITYSERVICE_H
#define CASE_STUDY_FACILITYSERVICE_H


class FacilityService {

};


#endif //CASE_STUDY_FACILITYSERVICE_H
