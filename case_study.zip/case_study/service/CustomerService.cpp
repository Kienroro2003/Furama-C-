//
// Created by Kienroro on 08/05/2022.
//

#include "CustomerService.h"
#include "../util/ReadAndWriteCustomer.h"

void CustomerService::add() {
    customerList = ReadAndWriteCustomer().readFile
            ("/Users/kienroro2003/Desktop/C++/Furama-C-/case_study/data/customer");
    string idCode = "KH-000" + to_string(customerList.size());
    cout << "Enter full name: ";
    string fullName;
    getline(cin, fullName);
    cout << "Enter birthday: ";
    string birthday;
    getline(cin, birthday);
    cout << "Enter gender: ";
    string gender;
    getline(cin, gender);
    cout << "Enter id card: ";
    string id;
    getline(cin, id);
    cout << "Enter phone number: ";
    string phoneNumber;
    getline(cin, phoneNumber);
    cout << "Enter email: ";
    string email;
    getline(cin, email);
    cout << "Enter type customer: ";
    string typeCustomer;
    getline(cin, typeCustomer);
    cout << "Enter address: ";
    string address;
    getline(cin, address);
    Customer customer(idCode, fullName, birthday, gender, id, phoneNumber, email, typeCustomer, address);
    customerList.push_back(customer);
    ReadAndWriteCustomer().writeFile("/Users/kienroro2003/Desktop/C++/Furama-C-/case_study/data/customer",
                                     customerList);

}

void CustomerService::display() {
    customerList = ReadAndWriteCustomer().readFile
            ("/Users/kienroro2003/Desktop/C++/Furama-C-/case_study/data/customer");
    for (Customer c: customerList) {
        c.output();
    }
}

void CustomerService::edit() {

}
